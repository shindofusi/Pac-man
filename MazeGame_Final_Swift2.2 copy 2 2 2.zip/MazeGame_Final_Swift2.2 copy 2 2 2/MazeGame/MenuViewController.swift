//
//  MenuViewController.swift
//  Pacman
//
//  Created by user121003 on 12/6/16.
//  Copyright © 2016 teampac. All rights reserved.
//

import Foundation
import UIKit
 
class MenuViewController: UIViewController {
}