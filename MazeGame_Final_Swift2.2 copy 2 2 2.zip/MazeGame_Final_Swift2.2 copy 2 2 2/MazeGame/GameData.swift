

import Foundation

var livesLeft:Int  =  3
var currentLevel:Int = 0
var firstSKSFile:String = "GameScene"
var currentSKSFile:String = firstSKSFile
